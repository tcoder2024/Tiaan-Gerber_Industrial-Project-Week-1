﻿namespace SmartStudentProfileProcessorV2
{
	partial class Form1
	{
		private System.ComponentModel.IContainer components = null;

		private System.Windows.Forms.Panel headerPanel;
		private System.Windows.Forms.Label titleLabel;
		private System.Windows.Forms.Label subtitleLabel;
		private System.Windows.Forms.TabControl mainTabControl;
		private System.Windows.Forms.TabPage addTab;
		private System.Windows.Forms.TabPage listTab;
		private System.Windows.Forms.TabPage analyticsTab;

		// Add Tab
		private System.Windows.Forms.GroupBox studentInfoGroup;
		private System.Windows.Forms.GroupBox scoresGroup;
		private System.Windows.Forms.GroupBox assessmentGroup;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.TextBox txtAge;
		private System.Windows.Forms.ComboBox cboCourse;
		private System.Windows.Forms.TextBox txtTest1;
		private System.Windows.Forms.TextBox txtTest2;
		private System.Windows.Forms.TextBox txtTest3;
		private System.Windows.Forms.TextBox txtAttendance;
		private System.Windows.Forms.ComboBox cboTechLevel;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Label lblNameError;
		private System.Windows.Forms.Label lblAgeError;
		private System.Windows.Forms.Label lblGeneralError;

		// List Tab
		private System.Windows.Forms.Panel topPanel;
		private System.Windows.Forms.Label lblSearch;
		private System.Windows.Forms.TextBox txtSearch;
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.Button btnRefresh;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Button btnExport;
		private System.Windows.Forms.DataGridView dgvStudents;
		private System.Windows.Forms.StatusStrip statusStrip;
		private System.Windows.Forms.ToolStripStatusLabel statusLabel;

		// Analytics Tab
		private System.Windows.Forms.Panel analyticsPanel;
		private System.Windows.Forms.Button btnRefreshAnalytics;
		private System.Windows.Forms.Label lblTotalLabel;
		private System.Windows.Forms.Label lblTotalValue;
		private System.Windows.Forms.Label lblAverageLabel;
		private System.Windows.Forms.Label lblAverageValue;
		private System.Windows.Forms.Label lblReadyLabel;
		private System.Windows.Forms.Label lblReadyValue;
		private System.Windows.Forms.Label lblPartialLabel;
		private System.Windows.Forms.Label lblPartialValue;
		private System.Windows.Forms.Label lblNotReadyLabel;
		private System.Windows.Forms.Label lblNotReadyValue;
		private System.Windows.Forms.Label lblTopLabel;
		private System.Windows.Forms.Label lblTopValue;
		private System.Windows.Forms.ProgressBar avgProgressBar;
		private System.Windows.Forms.Label lblProgressText;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
				components.Dispose();
			base.Dispose(disposing);
		}

        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            headerPanel = new Panel();
            titleLabel = new Label();
            subtitleLabel = new Label();
            mainTabControl = new TabControl();
            addTab = new TabPage();
            studentInfoGroup = new GroupBox();
            nameLabel = new Label();
            ageLabel = new Label();
            courseLabel = new Label();
            txtName = new TextBox();
            txtAge = new TextBox();
            cboCourse = new ComboBox();
            lblNameError = new Label();
            lblAgeError = new Label();
            scoresGroup = new GroupBox();
            test1Label = new Label();
            test2Label = new Label();
            test3Label = new Label();
            attendanceLabel = new Label();
            txtTest1 = new TextBox();
            txtTest2 = new TextBox();
            txtTest3 = new TextBox();
            txtAttendance = new TextBox();
            assessmentGroup = new GroupBox();
            techLabel = new Label();
            cboTechLevel = new ComboBox();
            btnAdd = new Button();
            btnClear = new Button();
            lblGeneralError = new Label();
            listTab = new TabPage();
            dgvStudents = new DataGridView();
            topPanel = new Panel();
            lblSearch = new Label();
            txtSearch = new TextBox();
            btnSearch = new Button();
            btnRefresh = new Button();
            btnDelete = new Button();
            btnExport = new Button();
            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel();
            analyticsTab = new TabPage();
            analyticsPanel = new Panel();
            btnRefreshAnalytics = new Button();
            lblProgressText = new Label();
            avgProgressBar = new ProgressBar();
            lblTotalLabel = new Label();
            lblTotalValue = new Label();
            lblAverageLabel = new Label();
            lblAverageValue = new Label();
            lblReadyLabel = new Label();
            lblReadyValue = new Label();
            lblPartialLabel = new Label();
            lblPartialValue = new Label();
            lblNotReadyLabel = new Label();
            lblNotReadyValue = new Label();
            lblTopLabel = new Label();
            lblTopValue = new Label();
            headerPanel.SuspendLayout();
            mainTabControl.SuspendLayout();
            addTab.SuspendLayout();
            studentInfoGroup.SuspendLayout();
            scoresGroup.SuspendLayout();
            assessmentGroup.SuspendLayout();
            listTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStudents).BeginInit();
            topPanel.SuspendLayout();
            statusStrip.SuspendLayout();
            analyticsTab.SuspendLayout();
            analyticsPanel.SuspendLayout();
            SuspendLayout();
            // 
            // headerPanel
            // 
            headerPanel.BackColor = Color.FromArgb(0, 122, 204);
            headerPanel.Controls.Add(titleLabel);
            headerPanel.Controls.Add(subtitleLabel);
            headerPanel.Dock = DockStyle.Top;
            headerPanel.Location = new Point(0, 0);
            headerPanel.Name = "headerPanel";
            headerPanel.Size = new Size(1082, 70);
            headerPanel.TabIndex = 1;
            // 
            // titleLabel
            // 
            titleLabel.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            titleLabel.ForeColor = Color.White;
            titleLabel.Location = new Point(20, 12);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(500, 30);
            titleLabel.TabIndex = 0;
            titleLabel.Text = "Smart Student Profile Processor";
            // 
            // subtitleLabel
            // 
            subtitleLabel.Font = new Font("Segoe UI", 9F);
            subtitleLabel.ForeColor = Color.FromArgb(220, 220, 220);
            subtitleLabel.Location = new Point(22, 42);
            subtitleLabel.Name = "subtitleLabel";
            subtitleLabel.Size = new Size(400, 20);
            subtitleLabel.TabIndex = 1;
            subtitleLabel.Text = "Kitumaini Digital Solutions | Professional Edition v2.0";
            // 
            // mainTabControl
            // 
            mainTabControl.Controls.Add(addTab);
            mainTabControl.Controls.Add(listTab);
            mainTabControl.Controls.Add(analyticsTab);
            mainTabControl.Dock = DockStyle.Fill;
            mainTabControl.Font = new Font("Segoe UI", 10F);
            mainTabControl.Location = new Point(0, 70);
            mainTabControl.Name = "mainTabControl";
            mainTabControl.SelectedIndex = 0;
            mainTabControl.Size = new Size(1082, 583);
            mainTabControl.TabIndex = 0;
            // 
            // addTab
            // 
            addTab.BackColor = Color.FromArgb(30, 30, 30);
            addTab.Controls.Add(studentInfoGroup);
            addTab.Controls.Add(scoresGroup);
            addTab.Controls.Add(assessmentGroup);
            addTab.Location = new Point(4, 32);
            addTab.Name = "addTab";
            addTab.Size = new Size(1074, 547);
            addTab.TabIndex = 0;
            addTab.Text = "Add Student";
            // 
            // studentInfoGroup
            // 
            studentInfoGroup.BackColor = Color.FromArgb(40, 40, 40);
            studentInfoGroup.Controls.Add(nameLabel);
            studentInfoGroup.Controls.Add(ageLabel);
            studentInfoGroup.Controls.Add(courseLabel);
            studentInfoGroup.Controls.Add(txtName);
            studentInfoGroup.Controls.Add(txtAge);
            studentInfoGroup.Controls.Add(cboCourse);
            studentInfoGroup.Controls.Add(lblNameError);
            studentInfoGroup.Controls.Add(lblAgeError);
            studentInfoGroup.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            studentInfoGroup.ForeColor = Color.White;
            studentInfoGroup.Location = new Point(20, 15);
            studentInfoGroup.Name = "studentInfoGroup";
            studentInfoGroup.Size = new Size(500, 180);
            studentInfoGroup.TabIndex = 0;
            studentInfoGroup.TabStop = false;
            studentInfoGroup.Text = "Student Information";
            // 
            // nameLabel
            // 
            nameLabel.Location = new Point(0, 0);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(100, 23);
            nameLabel.TabIndex = 0;
            // 
            // ageLabel
            // 
            ageLabel.Location = new Point(0, 0);
            ageLabel.Name = "ageLabel";
            ageLabel.Size = new Size(100, 23);
            ageLabel.TabIndex = 1;
            // 
            // courseLabel
            // 
            courseLabel.Location = new Point(0, 0);
            courseLabel.Name = "courseLabel";
            courseLabel.Size = new Size(100, 23);
            courseLabel.TabIndex = 2;
            // 
            // txtName
            // 
            txtName.BackColor = Color.FromArgb(60, 60, 60);
            txtName.ForeColor = Color.White;
            txtName.Location = new Point(120, 28);
            txtName.Name = "txtName";
            txtName.Size = new Size(350, 30);
            txtName.TabIndex = 3;
            // 
            // txtAge
            // 
            txtAge.BackColor = Color.FromArgb(60, 60, 60);
            txtAge.ForeColor = Color.White;
            txtAge.Location = new Point(120, 63);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(120, 30);
            txtAge.TabIndex = 4;
            // 
            // cboCourse
            // 
            cboCourse.BackColor = Color.FromArgb(60, 60, 60);
            cboCourse.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCourse.ForeColor = Color.White;
            cboCourse.Items.AddRange(new object[] { "Programming", "Data Science", "Cyber Security" });
            cboCourse.Location = new Point(120, 98);
            cboCourse.Name = "cboCourse";
            cboCourse.Size = new Size(200, 31);
            cboCourse.TabIndex = 5;
            // 
            // lblNameError
            // 
            lblNameError.Font = new Font("Segoe UI", 8F);
            lblNameError.ForeColor = Color.FromArgb(241, 76, 76);
            lblNameError.Location = new Point(120, 55);
            lblNameError.Name = "lblNameError";
            lblNameError.Size = new Size(350, 20);
            lblNameError.TabIndex = 6;
            // 
            // lblAgeError
            // 
            lblAgeError.Font = new Font("Segoe UI", 8F);
            lblAgeError.ForeColor = Color.FromArgb(241, 76, 76);
            lblAgeError.Location = new Point(250, 63);
            lblAgeError.Name = "lblAgeError";
            lblAgeError.Size = new Size(220, 20);
            lblAgeError.TabIndex = 7;
            // 
            // scoresGroup
            // 
            scoresGroup.BackColor = Color.FromArgb(40, 40, 40);
            scoresGroup.Controls.Add(test1Label);
            scoresGroup.Controls.Add(test2Label);
            scoresGroup.Controls.Add(test3Label);
            scoresGroup.Controls.Add(attendanceLabel);
            scoresGroup.Controls.Add(txtTest1);
            scoresGroup.Controls.Add(txtTest2);
            scoresGroup.Controls.Add(txtTest3);
            scoresGroup.Controls.Add(txtAttendance);
            scoresGroup.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            scoresGroup.ForeColor = Color.White;
            scoresGroup.Location = new Point(540, 15);
            scoresGroup.Name = "scoresGroup";
            scoresGroup.Size = new Size(250, 250);
            scoresGroup.TabIndex = 1;
            scoresGroup.TabStop = false;
            scoresGroup.Text = "Test Scores (0-100)";
            // 
            // test1Label
            // 
            test1Label.Location = new Point(0, 0);
            test1Label.Name = "test1Label";
            test1Label.Size = new Size(100, 23);
            test1Label.TabIndex = 0;
            // 
            // test2Label
            // 
            test2Label.Location = new Point(0, 0);
            test2Label.Name = "test2Label";
            test2Label.Size = new Size(100, 23);
            test2Label.TabIndex = 1;
            // 
            // test3Label
            // 
            test3Label.Location = new Point(0, 0);
            test3Label.Name = "test3Label";
            test3Label.Size = new Size(100, 23);
            test3Label.TabIndex = 2;
            // 
            // attendanceLabel
            // 
            attendanceLabel.Location = new Point(0, 0);
            attendanceLabel.Name = "attendanceLabel";
            attendanceLabel.Size = new Size(100, 23);
            attendanceLabel.TabIndex = 3;
            // 
            // txtTest1
            // 
            txtTest1.BackColor = Color.FromArgb(60, 60, 60);
            txtTest1.ForeColor = Color.White;
            txtTest1.Location = new Point(120, 28);
            txtTest1.Name = "txtTest1";
            txtTest1.Size = new Size(100, 30);
            txtTest1.TabIndex = 4;
            // 
            // txtTest2
            // 
            txtTest2.BackColor = Color.FromArgb(60, 60, 60);
            txtTest2.ForeColor = Color.White;
            txtTest2.Location = new Point(120, 68);
            txtTest2.Name = "txtTest2";
            txtTest2.Size = new Size(100, 30);
            txtTest2.TabIndex = 5;
            // 
            // txtTest3
            // 
            txtTest3.BackColor = Color.FromArgb(60, 60, 60);
            txtTest3.ForeColor = Color.White;
            txtTest3.Location = new Point(120, 108);
            txtTest3.Name = "txtTest3";
            txtTest3.Size = new Size(100, 30);
            txtTest3.TabIndex = 6;
            // 
            // txtAttendance
            // 
            txtAttendance.BackColor = Color.FromArgb(60, 60, 60);
            txtAttendance.ForeColor = Color.White;
            txtAttendance.Location = new Point(120, 148);
            txtAttendance.Name = "txtAttendance";
            txtAttendance.Size = new Size(100, 30);
            txtAttendance.TabIndex = 7;
            // 
            // assessmentGroup
            // 
            assessmentGroup.BackColor = Color.FromArgb(40, 40, 40);
            assessmentGroup.Controls.Add(techLabel);
            assessmentGroup.Controls.Add(cboTechLevel);
            assessmentGroup.Controls.Add(btnAdd);
            assessmentGroup.Controls.Add(btnClear);
            assessmentGroup.Controls.Add(lblGeneralError);
            assessmentGroup.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            assessmentGroup.ForeColor = Color.White;
            assessmentGroup.Location = new Point(810, 15);
            assessmentGroup.Name = "assessmentGroup";
            assessmentGroup.Size = new Size(260, 180);
            assessmentGroup.TabIndex = 2;
            assessmentGroup.TabStop = false;
            assessmentGroup.Text = "Assessment";
            // 
            // techLabel
            // 
            techLabel.Location = new Point(0, 0);
            techLabel.Name = "techLabel";
            techLabel.Size = new Size(100, 23);
            techLabel.TabIndex = 0;
            // 
            // cboTechLevel
            // 
            cboTechLevel.BackColor = Color.FromArgb(60, 60, 60);
            cboTechLevel.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTechLevel.ForeColor = Color.White;
            cboTechLevel.Items.AddRange(new object[] { "1 - Beginner", "2", "3 - Intermediate", "4", "5 - Expert" });
            cboTechLevel.Location = new Point(15, 60);
            cboTechLevel.Name = "cboTechLevel";
            cboTechLevel.Size = new Size(220, 31);
            cboTechLevel.TabIndex = 1;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(0, 122, 204);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(15, 110);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(120, 40);
            btnAdd.TabIndex = 2;
            btnAdd.Text = "Add Student";
            btnAdd.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(60, 60, 60);
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.ForeColor = Color.White;
            btnClear.Location = new Point(145, 110);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(100, 40);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear Form";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // lblGeneralError
            // 
            lblGeneralError.Font = new Font("Segoe UI", 8F);
            lblGeneralError.ForeColor = Color.FromArgb(241, 76, 76);
            lblGeneralError.Location = new Point(15, 165);
            lblGeneralError.Name = "lblGeneralError";
            lblGeneralError.Size = new Size(230, 40);
            lblGeneralError.TabIndex = 4;
            // 
            // listTab
            // 
            listTab.BackColor = Color.FromArgb(30, 30, 30);
            listTab.Controls.Add(dgvStudents);
            listTab.Controls.Add(topPanel);
            listTab.Controls.Add(statusStrip);
            listTab.Location = new Point(4, 32);
            listTab.Name = "listTab";
            listTab.Size = new Size(1074, 547);
            listTab.TabIndex = 1;
            listTab.Text = "Student List";
            // 
            // dgvStudents
            // 
            dgvStudents.AllowUserToAddRows = false;
            dgvStudents.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvStudents.BackgroundColor = Color.FromArgb(30, 30, 30);
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(0, 122, 204);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = Color.White;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvStudents.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvStudents.ColumnHeadersHeight = 29;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(45, 45, 45);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(0, 122, 204);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvStudents.DefaultCellStyle = dataGridViewCellStyle2;
            dgvStudents.Dock = DockStyle.Fill;
            dgvStudents.GridColor = Color.FromArgb(60, 60, 60);
            dgvStudents.Location = new Point(0, 50);
            dgvStudents.Name = "dgvStudents";
            dgvStudents.RowHeadersVisible = false;
            dgvStudents.RowHeadersWidth = 51;
            dgvStudents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStudents.Size = new Size(1074, 471);
            dgvStudents.TabIndex = 0;
            // 
            // topPanel
            // 
            topPanel.BackColor = Color.FromArgb(45, 45, 45);
            topPanel.Controls.Add(lblSearch);
            topPanel.Controls.Add(txtSearch);
            topPanel.Controls.Add(btnSearch);
            topPanel.Controls.Add(btnRefresh);
            topPanel.Controls.Add(btnDelete);
            topPanel.Controls.Add(btnExport);
            topPanel.Dock = DockStyle.Top;
            topPanel.Location = new Point(0, 0);
            topPanel.Name = "topPanel";
            topPanel.Size = new Size(1074, 50);
            topPanel.TabIndex = 1;
            // 
            // lblSearch
            // 
            lblSearch.ForeColor = Color.White;
            lblSearch.Location = new Point(15, 15);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(60, 25);
            lblSearch.TabIndex = 0;
            lblSearch.Text = "Search:";
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.FromArgb(60, 60, 60);
            txtSearch.ForeColor = Color.White;
            txtSearch.Location = new Point(75, 12);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(200, 30);
            txtSearch.TabIndex = 1;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.FromArgb(0, 122, 204);
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(285, 10);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(80, 32);
            btnSearch.TabIndex = 2;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = Color.FromArgb(60, 60, 60);
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.ForeColor = Color.White;
            btnRefresh.Location = new Point(375, 10);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(80, 32);
            btnRefresh.TabIndex = 3;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(200, 50, 50);
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(850, 10);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(110, 32);
            btnDelete.TabIndex = 4;
            btnDelete.Text = "Delete Selected";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnExport
            // 
            btnExport.BackColor = Color.FromArgb(106, 153, 85);
            btnExport.FlatStyle = FlatStyle.Flat;
            btnExport.ForeColor = Color.White;
            btnExport.Location = new Point(970, 10);
            btnExport.Name = "btnExport";
            btnExport.Size = new Size(100, 32);
            btnExport.TabIndex = 5;
            btnExport.Text = "Export to DB";
            btnExport.UseVisualStyleBackColor = false;
            // 
            // statusStrip
            // 
            statusStrip.BackColor = Color.FromArgb(30, 30, 30);
            statusStrip.ImageScalingSize = new Size(20, 20);
            statusStrip.Items.AddRange(new ToolStripItem[] { statusLabel });
            statusStrip.Location = new Point(0, 521);
            statusStrip.Name = "statusStrip";
            statusStrip.Size = new Size(1074, 26);
            statusStrip.TabIndex = 2;
            // 
            // statusLabel
            // 
            statusLabel.ForeColor = Color.White;
            statusLabel.Name = "statusLabel";
            statusLabel.Size = new Size(50, 20);
            statusLabel.Text = "Ready";
            // 
            // analyticsTab
            // 
            analyticsTab.BackColor = Color.FromArgb(30, 30, 30);
            analyticsTab.Controls.Add(analyticsPanel);
            analyticsTab.Location = new Point(4, 32);
            analyticsTab.Name = "analyticsTab";
            analyticsTab.Size = new Size(1074, 547);
            analyticsTab.TabIndex = 2;
            analyticsTab.Text = "Analytics";
            // 
            // analyticsPanel
            // 
            analyticsPanel.BackColor = Color.FromArgb(40, 40, 40);
            analyticsPanel.Controls.Add(btnRefreshAnalytics);
            analyticsPanel.Controls.Add(lblProgressText);
            analyticsPanel.Controls.Add(avgProgressBar);
            analyticsPanel.Controls.Add(lblTotalLabel);
            analyticsPanel.Controls.Add(lblTotalValue);
            analyticsPanel.Controls.Add(lblAverageLabel);
            analyticsPanel.Controls.Add(lblAverageValue);
            analyticsPanel.Controls.Add(lblReadyLabel);
            analyticsPanel.Controls.Add(lblReadyValue);
            analyticsPanel.Controls.Add(lblPartialLabel);
            analyticsPanel.Controls.Add(lblPartialValue);
            analyticsPanel.Controls.Add(lblNotReadyLabel);
            analyticsPanel.Controls.Add(lblNotReadyValue);
            analyticsPanel.Controls.Add(lblTopLabel);
            analyticsPanel.Controls.Add(lblTopValue);
            analyticsPanel.Dock = DockStyle.Fill;
            analyticsPanel.Location = new Point(0, 0);
            analyticsPanel.Name = "analyticsPanel";
            analyticsPanel.Size = new Size(1074, 547);
            analyticsPanel.TabIndex = 0;
            // 
            // btnRefreshAnalytics
            // 
            btnRefreshAnalytics.BackColor = Color.FromArgb(0, 122, 204);
            btnRefreshAnalytics.FlatStyle = FlatStyle.Flat;
            btnRefreshAnalytics.ForeColor = Color.White;
            btnRefreshAnalytics.Location = new Point(20, 20);
            btnRefreshAnalytics.Name = "btnRefreshAnalytics";
            btnRefreshAnalytics.Size = new Size(160, 40);
            btnRefreshAnalytics.TabIndex = 0;
            btnRefreshAnalytics.Text = "Refresh Analytics";
            btnRefreshAnalytics.UseVisualStyleBackColor = false;
            // 
            // lblProgressText
            // 
            lblProgressText.ForeColor = Color.White;
            lblProgressText.Location = new Point(20, 80);
            lblProgressText.Name = "lblProgressText";
            lblProgressText.Size = new Size(200, 25);
            lblProgressText.TabIndex = 1;
            lblProgressText.Text = "Average Readiness Score:";
            // 
            // avgProgressBar
            // 
            avgProgressBar.Location = new Point(20, 110);
            avgProgressBar.Name = "avgProgressBar";
            avgProgressBar.Size = new Size(500, 30);
            avgProgressBar.TabIndex = 2;
            // 
            // lblTotalLabel
            // 
            lblTotalLabel.Font = new Font("Segoe UI", 11F);
            lblTotalLabel.ForeColor = Color.FromArgb(180, 180, 180);
            lblTotalLabel.Location = new Point(20, 170);
            lblTotalLabel.Name = "lblTotalLabel";
            lblTotalLabel.Size = new Size(180, 30);
            lblTotalLabel.TabIndex = 3;
            lblTotalLabel.Text = "Total Students:";
            // 
            // lblTotalValue
            // 
            lblTotalValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTotalValue.ForeColor = Color.White;
            lblTotalValue.Location = new Point(200, 170);
            lblTotalValue.Name = "lblTotalValue";
            lblTotalValue.Size = new Size(200, 30);
            lblTotalValue.TabIndex = 4;
            // 
            // lblAverageLabel
            // 
            lblAverageLabel.Font = new Font("Segoe UI", 11F);
            lblAverageLabel.ForeColor = Color.FromArgb(180, 180, 180);
            lblAverageLabel.Location = new Point(20, 170);
            lblAverageLabel.Name = "lblAverageLabel";
            lblAverageLabel.Size = new Size(180, 30);
            lblAverageLabel.TabIndex = 5;
            lblAverageLabel.Text = "Average Readiness:";
            // 
            // lblAverageValue
            // 
            lblAverageValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblAverageValue.ForeColor = Color.FromArgb(0, 122, 204);
            lblAverageValue.Location = new Point(200, 170);
            lblAverageValue.Name = "lblAverageValue";
            lblAverageValue.Size = new Size(200, 30);
            lblAverageValue.TabIndex = 6;
            // 
            // lblReadyLabel
            // 
            lblReadyLabel.Font = new Font("Segoe UI", 11F);
            lblReadyLabel.ForeColor = Color.FromArgb(180, 180, 180);
            lblReadyLabel.Location = new Point(20, 170);
            lblReadyLabel.Name = "lblReadyLabel";
            lblReadyLabel.Size = new Size(180, 30);
            lblReadyLabel.TabIndex = 7;
            lblReadyLabel.Text = "Ready (80-100%):";
            // 
            // lblReadyValue
            // 
            lblReadyValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblReadyValue.ForeColor = Color.FromArgb(106, 153, 85);
            lblReadyValue.Location = new Point(200, 170);
            lblReadyValue.Name = "lblReadyValue";
            lblReadyValue.Size = new Size(200, 30);
            lblReadyValue.TabIndex = 8;
            // 
            // lblPartialLabel
            // 
            lblPartialLabel.Font = new Font("Segoe UI", 11F);
            lblPartialLabel.ForeColor = Color.FromArgb(180, 180, 180);
            lblPartialLabel.Location = new Point(20, 170);
            lblPartialLabel.Name = "lblPartialLabel";
            lblPartialLabel.Size = new Size(180, 30);
            lblPartialLabel.TabIndex = 9;
            lblPartialLabel.Text = "Partial (60-79%):";
            // 
            // lblPartialValue
            // 
            lblPartialValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblPartialValue.ForeColor = Color.FromArgb(241, 196, 15);
            lblPartialValue.Location = new Point(200, 170);
            lblPartialValue.Name = "lblPartialValue";
            lblPartialValue.Size = new Size(200, 30);
            lblPartialValue.TabIndex = 10;
            // 
            // lblNotReadyLabel
            // 
            lblNotReadyLabel.Font = new Font("Segoe UI", 11F);
            lblNotReadyLabel.ForeColor = Color.FromArgb(180, 180, 180);
            lblNotReadyLabel.Location = new Point(20, 170);
            lblNotReadyLabel.Name = "lblNotReadyLabel";
            lblNotReadyLabel.Size = new Size(180, 30);
            lblNotReadyLabel.TabIndex = 11;
            lblNotReadyLabel.Text = "Not Ready (0-59%):";
            // 
            // lblNotReadyValue
            // 
            lblNotReadyValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblNotReadyValue.ForeColor = Color.FromArgb(241, 76, 76);
            lblNotReadyValue.Location = new Point(200, 170);
            lblNotReadyValue.Name = "lblNotReadyValue";
            lblNotReadyValue.Size = new Size(200, 30);
            lblNotReadyValue.TabIndex = 12;
            // 
            // lblTopLabel
            // 
            lblTopLabel.Font = new Font("Segoe UI", 11F);
            lblTopLabel.ForeColor = Color.FromArgb(180, 180, 180);
            lblTopLabel.Location = new Point(20, 170);
            lblTopLabel.Name = "lblTopLabel";
            lblTopLabel.Size = new Size(180, 30);
            lblTopLabel.TabIndex = 13;
            lblTopLabel.Text = "Top Performer:";
            // 
            // lblTopValue
            // 
            lblTopValue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTopValue.ForeColor = Color.FromArgb(0, 122, 204);
            lblTopValue.Location = new Point(200, 170);
            lblTopValue.Name = "lblTopValue";
            lblTopValue.Size = new Size(600, 30);
            lblTopValue.TabIndex = 14;
            // 
            // Form1
            // 
            BackColor = Color.FromArgb(30, 30, 30);
            ClientSize = new Size(1082, 653);
            Controls.Add(mainTabControl);
            Controls.Add(headerPanel);
            MinimumSize = new Size(900, 600);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Smart Student Profile Processor v2.0";
            headerPanel.ResumeLayout(false);
            mainTabControl.ResumeLayout(false);
            addTab.ResumeLayout(false);
            studentInfoGroup.ResumeLayout(false);
            studentInfoGroup.PerformLayout();
            scoresGroup.ResumeLayout(false);
            scoresGroup.PerformLayout();
            assessmentGroup.ResumeLayout(false);
            listTab.ResumeLayout(false);
            listTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStudents).EndInit();
            topPanel.ResumeLayout(false);
            topPanel.PerformLayout();
            statusStrip.ResumeLayout(false);
            statusStrip.PerformLayout();
            analyticsTab.ResumeLayout(false);
            analyticsPanel.ResumeLayout(false);
            ResumeLayout(false);
        }

        private Label nameLabel;
        private Label ageLabel;
        private Label courseLabel;
        private Label test1Label;
        private Label test2Label;
        private Label test3Label;
        private Label attendanceLabel;
        private Label techLabel;
    }
}