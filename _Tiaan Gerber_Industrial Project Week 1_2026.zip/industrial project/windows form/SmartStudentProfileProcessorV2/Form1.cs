using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace SmartStudentProfileProcessorV2
{
    public partial class Form1 : Form
    {
        private List<Student> students = new List<Student>();
        private const string DataFile = "students.csv";

        public Form1()
        {
            InitializeComponent();
            SetupDataGridViewStyles();
            LoadData();
            RefreshStudentList();
            UpdateAnalytics();

            // Wire up events
            btnAdd.Click += BtnAdd_Click;
            btnClear.Click += BtnClear_Click;
            btnSearch.Click += BtnSearch_Click;
            btnRefresh.Click += BtnRefresh_Click;
            btnDelete.Click += BtnDelete_Click;
            btnExport.Click += BtnExport_Click;
            btnRefreshAnalytics.Click += BtnRefreshAnalytics_Click;
            txtSearch.TextChanged += TxtSearch_TextChanged;
        }

        private void SetupDataGridViewStyles()
        {
            dgvStudents.AutoGenerateColumns = true;
            dgvStudents.ReadOnly = true;
        }

        private void LoadData()
        {
            if (!File.Exists(DataFile)) return;

            try
            {
                string[] lines = File.ReadAllLines(DataFile);
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] parts = lines[i].Split(',');
                    if (parts.Length >= 11)
                    {
                        try
                        {
                            int techLevel = int.Parse(parts[8]);
                            var student = new Student(
                                parts[1], int.Parse(parts[2]), parts[3],
                                double.Parse(parts[4]), double.Parse(parts[5]), double.Parse(parts[6]),
                                double.Parse(parts[7]), techLevel
                            );
                            student.Id = int.Parse(parts[0]);
                            student.ReadinessScore = double.Parse(parts[9]);
                            students.Add(student);
                        }
                        catch (Exception) { }
                    }
                }
                UpdateStatus($"Loaded {students.Count} students");
            }
            catch (Exception ex)
            {
                UpdateStatus($"Load error: {ex.Message}");
            }
        }

        private void SaveData()
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(DataFile))
                {
                    writer.WriteLine("Id,Name,Age,Course,Test1,Test2,Test3,Attendance,Tech,Readiness,CreatedAt");
                    foreach (var student in students)
                    {
                        writer.WriteLine(student.ToCsv());
                    }
                }
                UpdateStatus($"Saved {students.Count} students");
            }
            catch (Exception ex)
            {
                UpdateStatus($"Save error: {ex.Message}");
            }
        }

        private void RefreshStudentList()
        {
            dgvStudents.DataSource = null;
            dgvStudents.DataSource = students.Select(s => new
            {
                s.Id,
                s.FullName,
                s.Age,
                s.Course,
                TestAverage = s.TestAverage.ToString("F1"),
                Readiness = s.ReadinessScore.ToString("F1") + "%",
                Level = s.GetReadinessLevel()
            }).ToList();

            UpdateStatus($"{students.Count} student(s) loaded");
        }

        private void UpdateAnalytics()
        {
            if (students.Count == 0)
            {
                lblTotalValue.Text = "0";
                lblAverageValue.Text = "N/A";
                lblReadyValue.Text = "0";
                lblPartialValue.Text = "0";
                lblNotReadyValue.Text = "0";
                lblTopValue.Text = "No students";
                avgProgressBar.Value = 0;
                return;
            }

            double totalScore = 0;
            int ready = 0, partial = 0, notReady = 0;

            foreach (var s in students)
            {
                totalScore += s.ReadinessScore;
                if (s.ReadinessScore >= 80) ready++;
                else if (s.ReadinessScore >= 60) partial++;
                else notReady++;
            }

            double average = totalScore / students.Count;
            var topStudent = students.OrderByDescending(s => s.ReadinessScore).First();

            lblTotalValue.Text = students.Count.ToString();
            lblAverageValue.Text = average.ToString("F1") + "%";
            lblReadyValue.Text = ready.ToString();
            lblPartialValue.Text = partial.ToString();
            lblNotReadyValue.Text = notReady.ToString();
            lblTopValue.Text = $"{topStudent.FullName} (ID: {topStudent.Id}) - {topStudent.ReadinessScore:F1}%";
            avgProgressBar.Value = (int)average;

            // Color coding for average
            if (average >= 80)
                lblAverageValue.ForeColor = Color.FromArgb(106, 153, 85);
            else if (average >= 60)
                lblAverageValue.ForeColor = Color.FromArgb(241, 196, 15);
            else
                lblAverageValue.ForeColor = Color.FromArgb(241, 76, 76);
        }

        private void UpdateStatus(string message)
        {
            statusLabel.Text = message;
        }

        private void ClearErrors()
        {
            lblNameError.Text = "";
            lblAgeError.Text = "";
            lblGeneralError.Text = "";
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                ClearErrors();

                string name = txtName.Text.Trim();
                if (string.IsNullOrWhiteSpace(name) || name.Length < 3)
                {
                    lblNameError.Text = "Name must be at least 3 characters";
                    return;
                }

                if (!int.TryParse(txtAge.Text, out int age) || age < 16 || age > 100)
                {
                    lblAgeError.Text = "Age must be between 16 and 100";
                    return;
                }

                if (!double.TryParse(txtTest1.Text, out double t1) || t1 < 0 || t1 > 100 ||
                    !double.TryParse(txtTest2.Text, out double t2) || t2 < 0 || t2 > 100 ||
                    !double.TryParse(txtTest3.Text, out double t3) || t3 < 0 || t3 > 100)
                {
                    lblGeneralError.Text = "Test scores must be between 0 and 100";
                    return;
                }

                if (!double.TryParse(txtAttendance.Text, out double attendance) || attendance < 0 || attendance > 100)
                {
                    lblGeneralError.Text = "Attendance must be between 0 and 100";
                    return;
                }

                if (cboTechLevel.SelectedIndex < 0)
                {
                    lblGeneralError.Text = "Please select a tech level";
                    return;
                }

                if (cboCourse.SelectedIndex < 0)
                {
                    cboCourse.SelectedIndex = 0;
                }

                int techLevel = cboTechLevel.SelectedIndex + 1;
                string course = cboCourse.SelectedItem.ToString();

                Student newStudent = new Student(name, age, course, t1, t2, t3, attendance, techLevel);
                students.Add(newStudent);
                SaveData();
                RefreshStudentList();
                UpdateAnalytics();
                BtnClear_Click(sender, e);

                MessageBox.Show($"Student added successfully!\n\nID: {newStudent.Id}\nName: {newStudent.FullName}\nReadiness Score: {newStudent.ReadinessScore:F1}%\nLevel: {newStudent.GetReadinessLevel()}",
                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex)
            {
                lblGeneralError.Text = ex.Message;
            }
            catch (Exception ex)
            {
                lblGeneralError.Text = $"Error: {ex.Message}";
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtAge.Clear();
            txtTest1.Clear();
            txtTest2.Clear();
            txtTest3.Clear();
            txtAttendance.Clear();
            cboCourse.SelectedIndex = -1;
            cboTechLevel.SelectedIndex = -1;
            ClearErrors();
            txtName.Focus();
        }

        private void PerformSearch()
        {
            string searchTerm = txtSearch.Text.Trim().ToLower();
            if (string.IsNullOrEmpty(searchTerm))
            {
                RefreshStudentList();
                return;
            }

            var results = students.Where(s =>
                s.FullName.ToLower().Contains(searchTerm) ||
                s.Id.ToString().Contains(searchTerm)).ToList();

            dgvStudents.DataSource = null;
            dgvStudents.DataSource = results.Select(s => new
            {
                s.Id,
                s.FullName,
                s.Age,
                s.Course,
                TestAverage = s.TestAverage.ToString("F1"),
                Readiness = s.ReadinessScore.ToString("F1") + "%",
                Level = s.GetReadinessLevel()
            }).ToList();

            UpdateStatus($"Found {results.Count} result(s)");
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            PerformSearch();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            PerformSearch();
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            RefreshStudentList();
            UpdateAnalytics();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0)
            {
                UpdateStatus("Please select a student to delete");
                return;
            }

            int selectedId = (int)dgvStudents.SelectedRows[0].Cells[0].Value;
            var student = students.Find(s => s.Id == selectedId);

            if (student != null)
            {
                var result = MessageBox.Show($"Delete {student.FullName} (ID: {student.Id})?\n\nThis action cannot be undone.",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    students.Remove(student);
                    SaveData();
                    RefreshStudentList();
                    UpdateAnalytics();
                    UpdateStatus($"Deleted: {student.FullName}");
                }
            }
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            if (students.Count == 0)
            {
                UpdateStatus("No students to export");
                MessageBox.Show("No students to export.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string exportData = "{" + Environment.NewLine;
            exportData += "  \"ExportDate\": \"" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\"," + Environment.NewLine;
            exportData += "  \"StudentCount\": " + students.Count + "," + Environment.NewLine;
            exportData += "  \"Students\": [" + Environment.NewLine;

            for (int i = 0; i < students.Count; i++)
            {
                var s = students[i];
                exportData += "    {" + Environment.NewLine;
                exportData += $"      \"StudentId\": {s.Id}," + Environment.NewLine;
                exportData += $"      \"FullName\": \"{s.FullName}\"," + Environment.NewLine;
                exportData += $"      \"Age\": {s.Age}," + Environment.NewLine;
                exportData += $"      \"Course\": \"{s.Course}\"," + Environment.NewLine;
                exportData += $"      \"TestAverage\": {s.TestAverage:F1}," + Environment.NewLine;
                exportData += $"      \"Attendance\": {s.AttendancePercentage:F1}," + Environment.NewLine;
                exportData += $"      \"ReadinessScore\": {s.ReadinessScore:F1}," + Environment.NewLine;
                exportData += $"      \"ReadinessLevel\": \"{s.GetReadinessLevel()}\"" + Environment.NewLine;
                exportData += "    }";
                if (i < students.Count - 1) exportData += ",";
                exportData += Environment.NewLine;
            }
            exportData += "  ]" + Environment.NewLine;
            exportData += "}";

            Clipboard.SetText(exportData);
            UpdateStatus("Exported to clipboard - ready for database");
            MessageBox.Show("Data exported to clipboard!\n\nJSON format ready for database/API insertion.",
                "Export Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnRefreshAnalytics_Click(object sender, EventArgs e)
        {
            UpdateAnalytics();
            UpdateStatus("Analytics refreshed");
        }

        private void listTab_Click(object sender, EventArgs e)
        {

        }
    }
}