﻿using System;

namespace SmartStudentProfileProcessorV2
{
	public class Student
	{
		public int Id { get; set; }
		public string FullName { get; set; }
		public int Age { get; set; }
		public string Course { get; set; }
		public double TestScore1 { get; set; }
		public double TestScore2 { get; set; }
		public double TestScore3 { get; set; }
		public double AttendancePercentage { get; set; }
		public int TechSelfAssessment { get; set; }
		public double ReadinessScore { get; set; }
		public DateTime CreatedAt { get; set; }

		public double TestAverage => (TestScore1 + TestScore2 + TestScore3) / 3;

		public Student(string fullName, int age, string course, double test1, double test2, double test3, double attendance, int techLevel)
		{
			if (string.IsNullOrWhiteSpace(fullName) || fullName.Length < 3)
				throw new ArgumentException("Name must be at least 3 characters");
			if (age < 16 || age > 100)
				throw new ArgumentException("Age must be between 16 and 100");
			if (test1 < 0 || test1 > 100 || test2 < 0 || test2 > 100 || test3 < 0 || test3 > 100)
				throw new ArgumentException("Test scores must be between 0 and 100");
			if (attendance < 0 || attendance > 100)
				throw new ArgumentException("Attendance must be between 0 and 100");
			if (techLevel < 1 || techLevel > 5)
				throw new ArgumentException("Tech assessment must be between 1 and 5");

			Id = new Random().Next(1000, 9999);
			FullName = fullName;
			Age = age;
			Course = course;
			TestScore1 = test1;
			TestScore2 = test2;
			TestScore3 = test3;
			AttendancePercentage = attendance;
			TechSelfAssessment = techLevel;
			CreatedAt = DateTime.Now;
			ReadinessScore = CalculateReadiness();
		}

		public double CalculateReadiness()
		{
			double techScoreConverted = TechSelfAssessment * 20;
			return (TestAverage * 0.5) + (AttendancePercentage * 0.3) + (techScoreConverted * 0.2);
		}

		public double CalculateReadiness(double testWeight, double attendanceWeight, double techWeight)
		{
			double techScoreConverted = TechSelfAssessment * 20;
			return (TestAverage * testWeight) + (AttendancePercentage * attendanceWeight) + (techScoreConverted * techWeight);
		}

		public static double CalculateReadiness(double testAverage, double attendance, int techLevel)
		{
			double techConverted = techLevel * 20;
			return (testAverage * 0.5) + (attendance * 0.3) + (techConverted * 0.2);
		}

		public string GetReadinessLevel()
		{
			if (ReadinessScore >= 80)
				return "Ready";
			else if (ReadinessScore >= 60)
				return "Partial";
			else
				return "Not Ready";
		}

		public string ToCsv()
		{
			return $"{Id},{FullName},{Age},{Course},{TestScore1},{TestScore2},{TestScore3},{AttendancePercentage},{TechSelfAssessment},{ReadinessScore:F1},{CreatedAt:yyyy-MM-dd HH:mm}";
		}

		public override string ToString()
		{
			return $"[{Id}] {FullName} - {ReadinessScore:F1}%";
		}
	}
}