﻿namespace SmartStudentProfileProcessor;

// Student class - proper OOP encapsulation
public class Student
{
	// Auto-implemented properties with validation in constructor
	public int Id { get; set; }
	public string FullName { get; set; }
	public int Age { get; set; }
	public string Course { get; set; }
	public double TestScore1 { get; set; }
	public double TestScore2 { get; set; }
	public double TestScore3 { get; set; }
	public double AttendancePercentage { get; set; }
	public int TechSelfAssessment { get; set; }
	public double ReadinessScore { get; set; }
	public DateTime CreatedAt { get; set; }

	// Calculated property - no storage needed
	public double TestAverage => (TestScore1 + TestScore2 + TestScore3) / 3;

	// Constructor with validation
	public Student(string fullName, int age, string course, double test1, double test2, double test3, double attendance, int techLevel)
	{
		// Validate all inputs before creating object
		if (string.IsNullOrWhiteSpace(fullName) || fullName.Length < 3)
			throw new ArgumentException("Name must be at least 3 characters");
		if (age < 16 || age > 100)
			throw new ArgumentException("Age must be between 16 and 100");
		if (test1 < 0 || test1 > 100 || test2 < 0 || test2 > 100 || test3 < 0 || test3 > 100)
			throw new ArgumentException("Test scores must be between 0 and 100");
		if (attendance < 0 || attendance > 100)
			throw new ArgumentException("Attendance must be between 0 and 100");
		if (techLevel < 1 || techLevel > 5)
			throw new ArgumentException("Tech assessment must be between 1 and 5");

		Id = new Random().Next(1000, 9999);
		FullName = fullName;
		Age = age;
		Course = course;
		TestScore1 = test1;
		TestScore2 = test2;
		TestScore3 = test3;
		AttendancePercentage = attendance;
		TechSelfAssessment = techLevel;
		CreatedAt = DateTime.Now;
		ReadinessScore = CalculateReadiness();
	}

	// PRIMARY METHOD - Calculates readiness score
	public double CalculateReadiness()
	{
		double techScoreConverted = TechSelfAssessment * 20;
		return (TestAverage * 0.5) + (AttendancePercentage * 0.3) + (techScoreConverted * 0.2);
	}

	// OVERLOADED METHOD 1 - Custom weights
	public double CalculateReadiness(double testWeight, double attendanceWeight, double techWeight)
	{
		double techScoreConverted = TechSelfAssessment * 20;
		return (TestAverage * testWeight) + (AttendancePercentage * attendanceWeight) + (techScoreConverted * techWeight);
	}

	// OVERLOADED METHOD 2 - Simplified version for quick calculation
	public static double CalculateReadiness(double testAverage, double attendance, int techLevel)
	{
		double techConverted = techLevel * 20;
		return (testAverage * 0.5) + (attendance * 0.3) + (techConverted * 0.2);
	}

	// Get readiness level with color mapping
	public (string Level, ConsoleColor Color) GetReadinessLevel()
	{
		if (ReadinessScore >= 80)
			return ("Ready", ConsoleColor.Green);
		else if (ReadinessScore >= 60)
			return ("Partial - Needs Prep", ConsoleColor.DarkYellow);
		else
			return ("Not Ready - Intervention", ConsoleColor.Red);
	}

	// Display student profile
	public void Display()
	{
		var (level, color) = GetReadinessLevel();

		Console.WriteLine($"| {Id,-6} | {FullName,-20} | {Age,-3} | {Course,-14} | {(TestAverage),-6:F1} | {ReadinessScore,-6:F1} |");
	}

	// Format for CSV export
	public string ToCsv()
	{
		return $"{Id},{FullName},{Age},{Course},{TestScore1},{TestScore2},{TestScore3},{AttendancePercentage},{TechSelfAssessment},{ReadinessScore:F1},{CreatedAt:yyyy-MM-dd HH:mm}";
	}

	public override string ToString()
	{
		return $"[{Id}] {FullName} | {Course} | Readiness: {ReadinessScore:F1}%";
	}
}

class Program
{
	private static List<Student> students = new List<Student>();
	private const string DataFile = "students.csv";

	static void Main(string[] args)
	{
		Console.Title = "Smart Student Profile Processor v2.0";

		PrintHeader();
		LoadFromFile();

		bool running = true;
		while (running)
		{
			PrintMenu();
			string choice = Console.ReadLine() ?? string.Empty;

			try
			{
				switch (choice)
				{
					case "1": AddStudent(); break;
					case "2": ViewAllStudents(); break;
					case "3": ViewStudentDetails(); break;
					case "4": CalculateReadinessReport(); break;
					case "5": ExportToDatabase(); break;
					case "6": SaveAndExit(); running = false; break;
					default: PrintError("Invalid option. Please try again."); break;
				}
			}
			catch (Exception ex)
			{
				PrintError($"Unexpected error: {ex.Message}");
			}
		}
	}

	static void PrintHeader()
	{
		Console.ForegroundColor = ConsoleColor.Cyan;
		Console.WriteLine("Smart Student Profile Processor v2.0");
		Console.ResetColor();
		Console.WriteLine("Kitumaini Digital Solutions | Professional Edition");
		Console.WriteLine(new string('=', 60));
		Console.WriteLine($"Students in system: {students.Count}");
		Console.WriteLine(new string('=', 60));
	}

	static void PrintMenu()
	{
		Console.ForegroundColor = ConsoleColor.Yellow;
		Console.WriteLine("\n[ MAIN MENU ]");
		Console.ResetColor();
		Console.WriteLine("1. Add New Student");
		Console.WriteLine("2. View All Students (Summary)");
		Console.WriteLine("3. View Student Details");
		Console.WriteLine("4. Readiness Report & Analytics");
		Console.WriteLine("5. Export to Database Format");
		Console.WriteLine("6. Save & Exit");
		Console.Write("\nYour choice: ");
	}

	static void AddStudent()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Cyan;
		Console.WriteLine("[ ADD NEW STUDENT ]");
		Console.ResetColor();
		Console.WriteLine(new string('-', 40));

		try
		{
			Console.Write("Full Name (min 3 chars): ");
			string name = Console.ReadLine() ?? string.Empty;

			Console.Write("Age (16-100): ");
			int age = int.Parse(Console.ReadLine() ?? "0");

			Console.WriteLine("\nCourses: 1=Programming | 2=Data Science | 3=Cyber Security");
			Console.Write("Select course (1-3): ");
			string courseChoice = Console.ReadLine() ?? string.Empty;
			string course = courseChoice switch
			{
				"1" => "Programming",
				"2" => "Data Science",
				"3" => "Cyber Security",
				_ => "Programming"
			};

			Console.Write("Test Score 1 (0-100): ");
			double t1 = double.Parse(Console.ReadLine() ?? "0");

			Console.Write("Test Score 2 (0-100): ");
			double t2 = double.Parse(Console.ReadLine() ?? "0");

			Console.Write("Test Score 3 (0-100): ");
			double t3 = double.Parse(Console.ReadLine() ?? "0");

			Console.Write("Attendance % (0-100): ");
			double attendance = double.Parse(Console.ReadLine() ?? "0");

			Console.Write("Tech Self-Assessment (1-5): ");
			int tech = int.Parse(Console.ReadLine() ?? "0");

			Student newStudent = new Student(name, age, course, t1, t2, t3, attendance, tech);
			students.Add(newStudent);

			// Demonstrate method overloading
			double standardScore = newStudent.CalculateReadiness();
			double weightAdjusted = newStudent.CalculateReadiness(0.6, 0.2, 0.2);

			Console.ForegroundColor = ConsoleColor.Green;
			Console.WriteLine($"\n[SUCCESS] Student added with ID: {newStudent.Id}");
			Console.WriteLine($"Standard Readiness: {standardScore:F1}%");
			Console.WriteLine($"Weight-Adjusted (60/20/20): {weightAdjusted:F1}%");
			Console.ResetColor();

			SaveToFile();
		}
		catch (ArgumentException ex)
		{
			PrintError($"Validation failed: {ex.Message}");
		}
		catch (FormatException)
		{
			PrintError("Invalid input format. Please enter correct numbers.");
		}

		Console.WriteLine("\nPress any key to continue...");
		Console.ReadKey();
	}

	static void ViewAllStudents()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Cyan;
		Console.WriteLine("[ ALL STUDENTS - SUMMARY VIEW ]");
		Console.ResetColor();
		Console.WriteLine(new string('=', 70));
		Console.WriteLine($"| {"ID",-6} | {"Name",-20} | {"Age",-3} | {"Course",-14} | {"Avg",-6} | {"Ready",-6} |");
		Console.WriteLine(new string('-', 70));

		if (students.Count == 0)
		{
			Console.WriteLine("| No students found. Please add a student first.                          |");
		}
		else
		{
			foreach (var student in students)
			{
				student.Display();
			}
		}

		Console.WriteLine(new string('-', 70));
		Console.WriteLine($"Total Students: {students.Count}");

		Console.WriteLine("\nPress any key to continue...");
		Console.ReadKey();
	}

	static void ViewStudentDetails()
	{
		if (students.Count == 0)
		{
			PrintError("No students found. Add a student first.");
			return;
		}

		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Cyan;
		Console.WriteLine("[ STUDENT DETAILS ]");
		Console.ResetColor();

		Console.Write("Enter Student ID: ");
		if (!int.TryParse(Console.ReadLine(), out int id))
		{
			PrintError("Invalid ID format.");
			return;
		}

		Student? student = students.Find(s => s.Id == id);
		if (student == null)
		{
			PrintError($"Student with ID {id} not found.");
			return;
		}

		var (level, color) = student.GetReadinessLevel();

		Console.WriteLine(new string('=', 50));
		Console.WriteLine($"ID:                 {student.Id}");
		Console.WriteLine($"Name:               {student.FullName}");
		Console.WriteLine($"Age:                {student.Age}");
		Console.WriteLine($"Course:             {student.Course}");
		Console.WriteLine($"Created:            {student.CreatedAt:yyyy-MM-dd HH:mm}");
		Console.WriteLine(new string('-', 50));
		Console.WriteLine($"Test Scores:        {student.TestScore1:F1}, {student.TestScore2:F1}, {student.TestScore3:F1}");
		Console.WriteLine($"Test Average:       {student.TestAverage:F1}");
		Console.WriteLine($"Attendance:         {student.AttendancePercentage:F1}%");
		Console.WriteLine($"Tech Assessment:    {student.TechSelfAssessment}/5");
		Console.WriteLine(new string('-', 50));
		Console.Write($"Readiness Score:    {student.ReadinessScore:F1}% -> ");
		Console.ForegroundColor = color;
		Console.WriteLine(level);
		Console.ResetColor();
		Console.WriteLine(new string('=', 50));

		Console.WriteLine("\nPress any key to continue...");
		Console.ReadKey();
	}

	static void CalculateReadinessReport()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Cyan;
		Console.WriteLine("[ READINESS ANALYTICS REPORT ]");
		Console.ResetColor();
		Console.WriteLine(new string('=', 50));

		if (students.Count == 0)
		{
			PrintError("No students to analyze.");
			return;
		}

		double totalScore = 0;
		int readyCount = 0, partialCount = 0, notReadyCount = 0;

		foreach (var student in students)
		{
			totalScore += student.ReadinessScore;

			if (student.ReadinessScore >= 80)
				readyCount++;
			else if (student.ReadinessScore >= 60)
				partialCount++;
			else
				notReadyCount++;
		}

		double averageScore = totalScore / students.Count;

		Console.WriteLine($"Total Students:     {students.Count}");
		Console.WriteLine($"Average Readiness:  {averageScore:F1}%");
		Console.WriteLine(new string('-', 50));
		Console.WriteLine("Readiness Distribution:");
		Console.WriteLine($"  Ready (80-100):    {readyCount} student(s)");
		Console.WriteLine($"  Partial (60-79):   {partialCount} student(s)");
		Console.WriteLine($"  Not Ready (0-59):  {notReadyCount} student(s)");
		Console.WriteLine(new string('=', 50));

		// Find top performer
		var topStudent = students.OrderByDescending(s => s.ReadinessScore).First();
		Console.WriteLine($"\nTop Performer: {topStudent.FullName} with {topStudent.ReadinessScore:F1}%");

		Console.WriteLine("\nPress any key to continue...");
		Console.ReadKey();
	}

	static void ExportToDatabase()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Cyan;
		Console.WriteLine("[ DATABASE EXPORT ]");
		Console.ResetColor();
		Console.WriteLine(new string('-', 50));

		if (students.Count == 0)
		{
			PrintError("No students to export.");
			return;
		}

		// JSON-like format for API/database
		Console.WriteLine("{\n  \"ExportDate\": \"" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\",");
		Console.WriteLine("  \"StudentCount\": " + students.Count + ",");
		Console.WriteLine("  \"Students\": [");

		for (int i = 0; i < students.Count; i++)
		{
			var s = students[i];
			Console.WriteLine($"    {{");
			Console.WriteLine($"      \"StudentId\": {s.Id},");
			Console.WriteLine($"      \"FullName\": \"{s.FullName}\",");
			Console.WriteLine($"      \"Course\": \"{s.Course}\",");
			Console.WriteLine($"      \"TestScores\": [{s.TestScore1:F1}, {s.TestScore2:F1}, {s.TestScore3:F1}],");
			Console.WriteLine($"      \"Attendance\": {s.AttendancePercentage:F1},");
			Console.WriteLine($"      \"ReadinessScore\": {s.ReadinessScore:F1}");
			Console.Write($"    }}");
			if (i < students.Count - 1) Console.Write(",");
			Console.WriteLine();
		}
		Console.WriteLine("  ]\n}");

		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("\n[READY FOR SQL/API INSERTION]");
		Console.ResetColor();

		Console.WriteLine("\nPress any key to continue...");
		Console.ReadKey();
	}

	static void SaveToFile()
	{
		try
		{
			using (StreamWriter writer = new StreamWriter(DataFile))
			{
				writer.WriteLine("Id,Name,Age,Course,Test1,Test2,Test3,Attendance,Tech,Readiness,CreatedAt");
				foreach (var student in students)
				{
					writer.WriteLine(student.ToCsv());
				}
			}
		}
		catch (Exception ex)
		{
			PrintError($"Failed to save: {ex.Message}");
		}
	}

	static void LoadFromFile()
	{
		if (!File.Exists(DataFile)) return;

		try
		{
			string[] lines = File.ReadAllLines(DataFile);
			for (int i = 1; i < lines.Length; i++) // Skip header
			{
				string[] parts = lines[i].Split(',');
				if (parts.Length >= 11)
				{
					var student = new Student(
						parts[1],  // Name
						int.Parse(parts[2]),  // Age
						parts[3],  // Course
						double.Parse(parts[4]),  // Test1
						double.Parse(parts[5]),  // Test2
						double.Parse(parts[6]),  // Test3
						double.Parse(parts[7]),  // Attendance
						int.Parse(parts[8])  // Tech
					);
					// Override ID and Readiness from file
					student.Id = int.Parse(parts[0]);
					student.ReadinessScore = double.Parse(parts[9]);
					students.Add(student);
				}
			}
			Console.WriteLine($"Loaded {students.Count} student(s) from previous session.");
		}
		catch (Exception ex)
		{
			Console.WriteLine($"Warning: Could not load previous data. {ex.Message}");
		}
	}

	static void SaveAndExit()
	{
		SaveToFile();
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine($"\nSaved {students.Count} student(s). Goodbye!");
		Console.ResetColor();
	}

	static void PrintError(string message)
	{
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine($"[ERROR] {message}");
		Console.ResetColor();
		Console.WriteLine("Press any key to continue...");
		Console.ReadKey();
	}
}